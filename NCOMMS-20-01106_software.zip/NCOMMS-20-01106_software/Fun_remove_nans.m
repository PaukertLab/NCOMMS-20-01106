function output = Fun_remove_nans(input)

m = size(input,1);
output = input;
for i = 1:m
    if isnan(output(m-i+1,1))
        output(m-i+1,:) = [];
    end
end
