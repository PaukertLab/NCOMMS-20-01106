% display(datestr(now));
% contamination: mean indROImedindi exceeds 3x SD (0.034)
%% Pseudocode:  (1) the average baseline standard deviation of the
% entire data set has been determined to be 0.034. For this sample test,
% sample data (indROImed_indi - each row represents one ROI's response) of one imaging session need to be loaded to the workspace
% from "Sample_Determine_contaminations.mat" and program needs to be "Run".
% (2) line 21: the mean fluorescence trace is calculated individual ROI responses. 
% (3) lines 22 to 31: Using dependency "Fun_contiguous_ones" the longest
% stretch of consecutive frames with the mean fluorescence trace exceeding
% 3x 0.034 will be determined - if that length is larger than 2 the trial
% will be labelled as contaminated ("1" instead of "0") in the variable "Judy_contamination".
%%
% path = '/Volumes/BigWhale/BG_PC_manuscript/Judy_Terminal_Data/';
% load([path,'list.mat'],'list');
% li = length(list);
li = 1;
Judy_contamination = [];
Judy_contamination = NaN(li,15);
for i = 1:li
%     load([path,'ana_reso_late_4_MP_',list{i,1},'.mat'],'indROImed_indi');
    data = nanmean(indROImed_indi,1);
    for j = 1:15
        test = data(1,((j-1)*410+1):((j-1)*410+179)) > (3*0.034);
        test = Fun_contiguous_ones(test);
        test = max(test(:,1));
        if test>2
            Judy_contamination(i,j) = 1;
        else
            Judy_contamination(i,j) = 0;
        end
    end
% end
% for i = 51:li
%     load([path,'ana_reso_late_4_MO_',list{i,1},'.mat'],'indROImed_indi');
%     data = nanmean(indROImed_indi,1);
%     for j = 1:15
%         test = data(1,((j-1)*410+1):((j-1)*410+179)) > (3*0.034);
%         test = Fun_contiguous_ones(test);
%         test = max(test(:,1));
%         if test>2
%             Judy_contamination(i,j) = 1;
%         else
%             Judy_contamination(i,j) = 0;
%         end
%     end
end
% display(datestr(now));