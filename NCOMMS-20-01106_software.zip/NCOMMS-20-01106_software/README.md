# NCOMMS-20-01106

This repository contains MATLAB functions that were developed to facilitate analysis and presentation of data
contained in

"Ethanol abolishes vigilance-dependent astroglia network activation in mice by inhibiting norepinephrine release"

by

Liang Ye#, Murat Orynbayev#, Xiangyu Zhu, Eunice Y. Lim, Ram R. Dereddi, Amit Agarwal, Dwight E. Bergles, Manzoor
A. Bhat and Martin Paukert*
(#, equal contribution; *, paukertm@uthscsa.edu)

Determine_contaminations.m serves to objectively determine whether an enforced locomotion trial has been
contaminated by preceding voluntary locomotion of the mouse, which would result in elimination of such a trial from
analysis. Instructions are provided as comments within the m-file.
Dependencies: Fun_contiguous_ones.m

Sample_Determine_contaminations.mat has been provided to test run this routine.


Fun_chained_dot_plot_SA_Feb2019.m serves to plot dependent or independent multi-factor data sets. Instructions are
provided as comments within the m-file.
Dependencies: N/A

Sample_chained_dot_plot.mat has been provided to test run this routine.


Fun_spread_dot_plot_SA_Nov2019.m serves to facilitate plotting of large sample size data sets. Instructions are
provided as comments within the m-file.
Dependencies: plotSpread.m, Fun_remove_nans.m

Sample_spread_dot_plot.mat has been provided to test run this routine.


License files for the plotSpread.m application and for the PaukertLab developments have been included.


System requirements: any system that allows to run MATLAB R2016a
Installation guide: included as comments in scripts, install time: 10 min
Demo: included as comments in scripts, run time: <1 s
Instructions for use: included as comments in scripts - sample data are provided for testing.


Address questions to Martin Paukert (paukertm@uthscsa.edu)

July 17, 2020

