function Fun_spread_dot_plot_SA_Nov2019(data,symbol_size_general)
% symbol_size_general: typically 10 - 18
% dependency:
% https://www.mathworks.com/matlabcentral/fileexchange/37105-plot-spread-points-beeswarm-plot
% (plotSpread)
% and Fun_remove_nans
%% Pseudocode:
% (1) Load "Sample_spread_dot_plot.mat" into workspace, paste
% "Fun_spread_dot_plot_SA_Nov2019(data,12);" into command line and press
% Enter.
% The function will determine whether the data are normally distributed and
% add mean and SEM symbols, or whether the data are non-normally
% distributed, in which case it will plot the median with as red symbol.
symbol_size_mean = 15;
data = Fun_remove_nans(data);
m = size(data,1);
lillie = lillietest(data);
if isequal(lillie,0)
    Mean = nanmean(data);
    SEM = std(data)/sqrt(m);
    plot([0 0],'color',[0 0 0 ],'LineWidth',1);
    set(gca,'XLim',[0.5 (1.5)],'NextPlot','add');
    set(gcf,'Tag','X');
    h = plotSpread(data);
    set(h{1},'MarkerSize',2*symbol_size_general);
    set(gca,'NextPlot','add');
    plot(1,Mean,'+','MarkerEdgeColor',[1 0 0],'MarkerFaceColor',[1 0 0],'MarkerSize',symbol_size_mean,'Color',[1 0 0],'LineWidth',3);
    set(gca,'NextPlot','add');
    errorbar(1,Mean,SEM,'color',[1 0 0],'LineWidth',3);
    set(gca,'NextPlot','add');
else
    Median = nanmedian(data);
    plot([0 0],'color',[0 0 0 ],'LineWidth',1);
    set(gca,'XLim',[0.5 (1.5)],'NextPlot','add');
    set(gcf,'Tag','X');
    h = plotSpread(data);
    set(h{1},'MarkerSize',2*symbol_size_general);
    set(gca,'NextPlot','add');
    plot(1,Median,'+','MarkerEdgeColor',[1 0 0],'MarkerFaceColor',[1 0 0],'MarkerSize',symbol_size_mean,'Color',[1 0 0],'LineWidth',3);
    set(gca,'NextPlot','add');
end
