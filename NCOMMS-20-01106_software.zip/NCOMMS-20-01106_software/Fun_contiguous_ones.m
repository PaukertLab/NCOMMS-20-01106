function output = Fun_contiguous_ones(input)

%input = isnan(input);
output = 0;
[m n] = size(input);
if m>n
    list = 0;
    x = 0;
    i = 0;
    while i<(m)
        i = i+1;
        if (i<(m+1) & isequal(input(i,1),1))
            x = x+1;
            i = i+1;
            while (i<(m+1) & isequal(input(i,1),1))
                x = x+1;
                i = i+1;
            end
            list = list+1;
            output(list,1) = x;
            output(list,2) = i-x;
            x = 0;
        end
    end
elseif isequal(m,n)
    list = 0;
    x = 0;
    i = 0;
    while i<(m)
        i = i+1;
        if (i<(m+1) & isequal(input(i,1),1))
            x = x+1;
            i = i+1;
            while (i<(m+1) & isequal(input(i,1),1))
                x = x+1;
                i = i+1;
            end
            list = list+1;
            output(list,1) = x;
            output(list,2) = i-x;
            x = 0;
        end
    end
else
    list = 0;
    x = 0;
    i = 0;
    while i<(n)
        i = i+1;
        if (i<(n+1) & isequal(input(1,i),1))
            x = x+1;
            i = i+1;
            while (i<(n+1) & isequal(input(1,i),1))
                x = x+1;
                i = i+1;
            end
            list = list+1;
            output(list,1) = x;
            output(list,2) = i-x;
            x = 0;
        end
    end
end
