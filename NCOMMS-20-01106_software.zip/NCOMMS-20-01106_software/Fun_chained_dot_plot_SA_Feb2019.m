function Fun_chained_dot_plot_SA_Feb2019(data,means,SEMs,symbol_size_general,colorset)
% for B/W: enter "[]" for colorset; for color: enter "1" for colorset
% symbol_size_general: typically 10 - 18
% for normally distributed data sets, means and SEMs are directly provided
% for non-normally distributed data sets, means are replaced by medians and
% SEMs are deleted from plot
% as sample load "Sample_chained_dot_plot.mat" into workspace, paste "Fun_chained_dot_plot_SA_Feb2019(data,means,SEMs,12,[]);" into command line and press
% Enter for black connecting lines.
% for colored connecting lines paste
% "Fun_chained_dot_plot_SA_Feb2019(data,means,SEMs,12,1);" into command
% line and press Enter.
symbol_size_mean = 15;
m = size(data,2);
if ~isempty(colorset)
    num = length(data) + round(0.12 * length(data));
    colorrange1 = parula(num);
    colorrange2 = lines(num);
    colorrange = (colorrange1+colorrange2)/2;
    zeroline(1,m) = 0;
    plot(zeroline(1,:),'color',[0 0 0 ],'LineWidth',1);
    set(gca,'XLim',[0.5 (m+0.5)],'NextPlot','add');
    set(gcf,'Tag','X');
    for i = 1:size(data,1)
        plot(1:m,data(i,1:m),'-o','MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0 0 0],'MarkerSize',symbol_size_general,'Color',colorrange(i,1:3),'LineWidth',2);
        set(gca,'NextPlot','add');
    end
    plot(1:m,means(1,1:m),'+','MarkerEdgeColor',[1 0 0],'MarkerFaceColor',[1 0 0],'MarkerSize',symbol_size_mean,'Color',[1 0 0],'LineWidth',3);
    set(gca,'NextPlot','add');
    errorbar(1:m,means(1,1:m),SEMs(1,1:m),'color',[1 0 0],'LineWidth',3);
    set(gca,'NextPlot','add');
else
    zeroline(1,m) = 0;
    plot(zeroline(1,:),'color',[0 0 0 ],'LineWidth',1);
    set(gca,'XLim',[0.5 (m+0.5)],'NextPlot','add');
    set(gcf,'Tag','X');
    for i = 1:size(data,1)
        plot(1:m,data(i,1:m),'-o','MarkerEdgeColor',[0 0 0],'MarkerFaceColor',[0 0 0],'MarkerSize',symbol_size_general,'Color',[0 0 0],'LineWidth',2);
        set(gca,'NextPlot','add');
    end
    plot(1:m,means(1,1:m),'+','MarkerEdgeColor',[1 0 0],'MarkerFaceColor',[1 0 0],'MarkerSize',symbol_size_mean,'Color',[1 0 0],'LineWidth',3);
    set(gca,'NextPlot','add');
    errorbar(1:m,means(1,1:m),SEMs(1,1:m),'color',[1 0 0],'LineWidth',3);
    set(gca,'NextPlot','add');
end
